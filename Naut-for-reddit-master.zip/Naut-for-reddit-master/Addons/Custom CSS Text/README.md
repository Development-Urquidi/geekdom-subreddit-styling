#Addon: Custom CSS Text

For customizing the css text, such as the downvote hover text, or the name of your subscribers in the sidebar. 

Please don't make them say something completely different that would confuse the user.
