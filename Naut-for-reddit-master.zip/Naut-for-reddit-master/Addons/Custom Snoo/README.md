#Addon: Custom Snoo

The Snoo is Reddit's alien mascotte. He's in the top-left! With this addon you can change Snoo with your own. 

Some notes:

* **The image should be 42px by 42px!**
* Make it clear for the user that clicking that image leads them back to Reddit's homepage. 
