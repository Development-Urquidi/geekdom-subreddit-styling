#Addon: Infobox ReColor

On the right, the sidebar box that contains the subscribe button and subreddit title/subscribers, that's the infobox. By default it's white, but with this addon you can change the background color very easily, like how it looks on /r/Naut. 

Some tips:

* It's **really** important that the color you choose fits well with the image in the infobox. If you take a general color from the image's palette, it almost always looks good!
* Keep in mind the subscribe button stands out less if you use a similar green or a really conflicting color. 
