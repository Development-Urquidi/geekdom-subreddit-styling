##Addon: Large Header

The default theme has a header that is 196px. This addon changes the header height to 294px.

**Make sure the header image you are using is 1920px by 294px.**
