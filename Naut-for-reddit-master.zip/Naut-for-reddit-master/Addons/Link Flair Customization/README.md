#Addon: Link Flair Customization

Link Flairs are helpful in labeling and categorizing content. **Please don't copy this addon directly, but judge whether you need each line in the addon.** Linkflairs are a great place to be creative, because you can influence the entire page for posts with just that Link Flair. Be creative!
