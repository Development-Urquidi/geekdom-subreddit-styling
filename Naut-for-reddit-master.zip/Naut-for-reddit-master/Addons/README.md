# nautAddons
This repository contains the reorganized folder structure for the Naut addons' GitHub page. Folder structure includes:

Content Overlap Header
---
    Content Overlap Header.css
    README.md
Custom CSS Text
---
    Custom CSS Text.css
    README.md
Custom Colors
---
    Custom Colors.css
    README.md
Custom Snoo
---
    Custom Snoo.css
    README.md
Custom Subreddit Title
---
    Custom Subreddit Title.css
    README.md
Infobox ReColor
---
    Infobox ReColor.css
    README.md
Large Header
---
    Large Header.css
    README.md
Link Flair Customization
---
    Link Flair Customization.css
    README.md
Remove Sidebar Image
---
    README.md
    Remove Sidebar Image.css
Small Header
---
    README.md
    Small Header.css
User Flair Images
---
    README.md
    User Flair Images.css
