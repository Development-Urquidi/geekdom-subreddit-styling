#Addon: Remove Sidebar Image

If you would like to remove the Sidebar Image that is included in the base Naut 4 Theme, use this addon. This will remove the Sidebar Image using margins. If you'd like to change the sidebar image, just replace the `sidebarimg` file with your own.

Thanks to /u/turikk
